<?php
function load_products_from_ini($filename) {
    if (!file_exists($filename)) {
        die("Файл $filename не найден.");
    }
    $products = parse_ini_file($filename, true);
    return $products;
}
function display_product_card($product) {
    echo "<div style='border: 1px solid #ccc; padding: 15px; margin: 10px; width: 300px;'>";
    echo "<h2>{$product['name']}</h2>";
    echo "<p><strong>Описание:</strong> {$product['description']}</p>";
    echo "<p><strong>Цена:</strong> {$product['price']} ₽</p>";
    echo "<p><strong>В наличии:</strong> {$product['stock']} шт.</p>";
    echo "<p><strong>ID товара:</strong> {$product['id']}</p>";
    echo "</div>";
}
function display_all_products($products) {
    echo "<div style='display: flex; flex-wrap: wrap;'>";
    foreach ($products as $product) {
        display_product_card($product);
    }
    echo "</div>";
}
$filename = 'products.ini';
$products = load_products_from_ini($filename);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>\Document</title>
</head>
<body>
    <h1>Каталог товаров</h1>
    <?php display_all_products($products); ?>
</body>
</html>